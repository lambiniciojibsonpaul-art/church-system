import { useState, useEffect } from "react";
import { restInsert, restSelect } from "../../supabaseRest";
import { useAuth } from "../../contexts/useAuth";
import { sendRequestEmail } from "../../emailNotifications";
import { supabase } from "../../supabaseClient"; 
import SignInPrompt from "../SignInPrompt";
import { DeclarationBlock, SuccessPanel, useProfileAutofill } from "./formHelpers";

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Helper function to generate time slots between 8:30 AM and 5:30 PM
function generateTimeSlots() {
  const slots = [];
  for (let hour = 8; hour <= 17; hour++) {
    const mins = hour === 8 ? ["30"] : ["00", "30"];
    for (let min of mins) {
      const time24 = `${hour.toString().padStart(2, "0")}:${min}`;
      const suffix = hour >= 12 ? "PM" : "AM";
      const displayHour = hour > 12 ? hour - 12 : hour;
      const displayTime = `${displayHour}:${min} ${suffix}`;
      slots.push({ value: time24, label: displayTime });
    }
  }
  return slots;
}

const TIME_SLOTS = generateTimeSlots();

async function submitGuestViaEdgeFunction(table, payload) {
  const res = await fetch(`${SUPABASE_URL}/functions/v1/submit-guest-form`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${SUPABASE_ANON}`,
      "apikey": SUPABASE_ANON,
    },
    body: JSON.stringify({ table, payload }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `Edge function error (${res.status})`);
  return json;
}

function BaptismFormModal({ onClose, guestInfo = null, onGuest }) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  
  const [priests, setPriests] = useState([]);
  const [sponsorInput, setSponsorInput] = useState("");

  const [formData, setFormData] = useState({
    baptismType: "Sunday",
    preferredDate: "",
    preferredTime: "",
    preferredPriest: "",
    childFirstName: "",
    childMiddleName: "",
    childLastName: "",
    childDob: "",
    childBirthplace: "",
    childGender: "",
    fatherName: "",
    motherMaidenName: "",
    address: "",
    contactNumbers: "",
    parentsMarriageStatus: "Married in Church",
    godfatherName: "",
    godmotherName: "",
    additionalSponsors: "",
    submitterName: "",
    submitter_signature: "",
    declaration_consent: false,
  });

  const autofill = useProfileAutofill(user);

  useEffect(() => {
    const fetchPriests = async () => {
      try {
        const { data, error } = await restSelect("priests", {
          match: { is_active: true },
          order: "name.asc",
        });
        if (!error && data) {
          setPriests(data);
        }
      } catch (err) {
        console.error("Error fetching priests:", err);
      }
    };
    fetchPriests();
  }, []);

  useEffect(() => {
    if (!autofill || guestInfo) return;
    setFormData(prev => ({
      ...prev,
      submitterName:        prev.submitterName        || autofill.fullName,
      contactNumbers:       prev.contactNumbers       || autofill.contactNumber,
      submitter_signature:  prev.submitter_signature  || autofill.fullName,
    }));
  }, [autofill, guestInfo]);

  useEffect(() => {
    if (!guestInfo) return;
    const fullName = `${guestInfo.firstName} ${guestInfo.lastName}`.trim();
    setFormData(prev => ({
      ...prev,
      submitterName:       prev.submitterName       || fullName,
      contactNumbers:      prev.contactNumbers      || guestInfo.contactNumber,
      submitter_signature: prev.submitter_signature || fullName,
    }));
  }, [guestInfo]);

  if (!user && !guestInfo) {
    return <SignInPrompt onClose={onClose} serviceName="a baptism" onGuest={onGuest} />;
  }

  const handleChange = (e) => {
    const { name, type, checked, value } = e.target;
    
    // Enforce numbers-only for the contact number field
    if (name === "contactNumbers") {
      const numbersOnly = value.replace(/\D/g, "");
      setFormData({ ...formData, [name]: numbersOnly });
      return;
    }
    
    setFormData({ ...formData, [name]: type === "checkbox" ? checked : value });
  };

  const sponsorsList = formData.additionalSponsors 
    ? formData.additionalSponsors.split(",").map(s => s.trim()).filter(Boolean) 
    : [];

  const handleAddSponsor = (e) => {
    e?.preventDefault();
    if (!sponsorInput.trim()) return;
    const newList = [...sponsorsList, sponsorInput.trim()];
    handleChange({ target: { name: "additionalSponsors", value: newList.join(", ") } });
    setSponsorInput("");
  };

  const handleRemoveSponsor = (indexToRemove) => {
    const newList = sponsorsList.filter((_, index) => index !== indexToRemove);
    handleChange({ target: { name: "additionalSponsors", value: newList.join(", ") } });
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddSponsor();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    if (!formData.declaration_consent) {
      setError("Please confirm the declaration before submitting.");
      return;
    }
    setLoading(true);

    try {
      const payload = {
        baptism_type: formData.baptismType,
        preferred_date: formData.preferredDate,
        preferred_time: formData.preferredTime,
        preferred_priest: formData.preferredPriest || null,
        child_first_name: formData.childFirstName,
        child_middle_name: formData.childMiddleName,
        child_last_name: formData.childLastName,
        child_dob: formData.childDob,
        child_birthplace: formData.childBirthplace,
        child_gender: formData.childGender,
        father_name: formData.fatherName,
        mother_maiden_name: formData.motherMaidenName,
        address: formData.address,
        contact_numbers: formData.contactNumbers,
        parents_marriage_status: formData.parentsMarriageStatus,
        godfather_name: formData.godfatherName,
        godmother_name: formData.godmotherName,
        additional_sponsors: formData.additionalSponsors,
        submitter_name: formData.submitter_signature,
        status: "Pending",
        ...(user ? {
          user_id: user.id,
          submitter_email: user.email || null,
          submitter_phone: user.user_metadata?.contact_number || user.phone || null,
        } : {}),
        ...(guestInfo ? {
          is_guest: true,
          guest_name: `${guestInfo.firstName} ${guestInfo.lastName}`.trim(),
          guest_contact: guestInfo.contactNumber,
        } : {}),
      };

      const parseErr = (raw) => {
        try {
          const p = JSON.parse(raw?.message ?? raw ?? "");
          return p.message || raw?.message || String(raw);
        } catch { return raw?.message || String(raw); }
      };

      // Guest path — use edge function (service role bypasses RLS)
      if (guestInfo && !user) {
        await submitGuestViaEdgeFunction("baptisms", payload);
      } else {
        const first = await restInsert("baptisms", [payload]);

        if (first.error) {
          const fallbackPayload = { ...payload };
          delete fallbackPayload.user_id;
          delete fallbackPayload.submitter_email;
          delete fallbackPayload.submitter_phone;

          const retry = await restInsert("baptisms", [fallbackPayload]);
          if (retry.error) {
            const minPayload = { ...fallbackPayload };
            delete minPayload.is_guest;
            delete minPayload.guest_name;
            delete minPayload.guest_contact;
            const lastRetry = await restInsert("baptisms", [minPayload]);
            if (lastRetry.error) throw new Error(parseErr(lastRetry.error));
          }
        }
      }

      // NOTIFY STAFF: Fire RPC after successful insert
      const submitterName = user
        ? (user.user_metadata?.first_name || user.email)
        : `${guestInfo?.firstName} ${guestInfo?.lastName}`.trim();

      const childName = [formData.childFirstName, formData.childLastName]
        .filter(Boolean).join(" ").trim();

      const { error: rpcError } = await supabase.rpc('notify_staff', {
        notif_title: `New Baptism Request`,
        notif_message: `${submitterName} submitted a baptism request for ${childName || "a child"}.`,
        notif_link: '/staff-dashboard',
        p_source_id: null,
        p_source_table: 'baptisms',
      });

      if (rpcError) {
        console.error("notify_staff RPC error:", rpcError);
      } else {
        console.log("✅ notify_staff fired successfully");
      }

      setSuccess(true);

      if (user?.email) {
        sendRequestEmail({
          to: user.email,
          serviceName: "baptism",
          summary: childName
            ? `Baptism request for ${childName} on ${formData.preferredDate || "(date pending)"}.`
            : undefined,
        });
      }

      setTimeout(() => {
        onClose();
      }, 2500);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 h-screen w-screen">
      <div className="bg-[#F6F5ED] w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-3xl shadow-2xl relative scrollbar-hidden">
        {/* Header */}
        <div className="sticky top-0 bg-[#F6F5ED] px-8 py-6 z-10 flex justify-between items-center border-b border-gray-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center border-2 border-[#B59E74] text-xl font-medium text-[#B59E74] shrink-0">
              ⛪
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-sans font-medium text-gray-800 uppercase tracking-wide">
                Basilica Minore de{" "}
                <span className="font-serif">San Pedro Bautista</span>
              </h2>
              <h1 className="text-2xl md:text-3xl text-[#B59E74] font-serif font-medium mt-1 uppercase">
                Baptism Registration Form
              </h1>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100 transition-colors text-gray-600 shrink-0"
          >
            ✕
          </button>
        </div>

        {success ? (
          <SuccessPanel />
        ) : (
          <form onSubmit={handleSubmit} className="p-8 space-y-10">
            {guestInfo && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-3">
                <span className="text-amber-500 text-lg shrink-0">👤</span>
                <div>
                  <p className="text-[10px] font-bold text-amber-700 uppercase tracking-widest">Guest Submission</p>
                  <p className="text-xs text-amber-600 mt-0.5">{guestInfo.firstName} {guestInfo.lastName} · {guestInfo.contactNumber}</p>
                </div>
              </div>
            )}
            {error && (
              <div className="bg-red-50 text-red-600 p-4 rounded-xl border border-red-200 text-sm font-bold">
                Error: {error}
              </div>
            )}

            {/* 1. Schedule Selection */}
            <div>
              <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest border-b border-[#B59E74]/30 pb-2 mb-4">
                Baptism Schedule & Officiant
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Type of Baptism *</label>
                  <select name="baptismType" value={formData.baptismType} onChange={handleChange} required
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700">
                    <option value="Sunday">Sunday Baptism</option>
                    <option value="Solo">Solo/Individual</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Preferred Date *</label>
                  <input type="date" name="preferredDate" value={formData.preferredDate} onChange={handleChange} required
                    min={new Date().toISOString().split("T")[0]}
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Preferred Time *</label>
                  <select name="preferredTime" value={formData.preferredTime} onChange={handleChange} required
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700">
                    <option value="" disabled>Select Time</option>
                    {TIME_SLOTS.map((slot) => (
                      <option key={slot.value} value={slot.value}>{slot.label}</option>
                    ))}
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Preferred Priest (Optional)</label>
                  <select name="preferredPriest" value={formData.preferredPriest} onChange={handleChange}
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700">
                    <option value="">No Preference / Any Available</option>
                    {priests.map((priest) => (
                      <option key={priest.id} value={priest.name}>Fr. {priest.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* 2. Child's Info */}
            <div>
              <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest border-b border-[#B59E74]/30 pb-2 mb-4">
                Child's Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="text-xs font-bold text-gray-600">Full Name of Child *</label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input type="text" name="childFirstName" value={formData.childFirstName} onChange={handleChange} required placeholder="First Name"
                      className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                    <input type="text" name="childMiddleName" value={formData.childMiddleName} onChange={handleChange} placeholder="Middle Name"
                      className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                    <input type="text" name="childLastName" value={formData.childLastName} onChange={handleChange} required placeholder="Last Name"
                      className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Date of Birth *</label>
                  <input type="date" name="childDob" value={formData.childDob} onChange={handleChange} required
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Place of Birth (City/Province) *</label>
                  <input type="text" name="childBirthplace" value={formData.childBirthplace} onChange={handleChange} required
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="text-xs font-bold text-gray-600">Gender *</label>
                  <div className="flex items-center gap-6 mt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                      <input type="radio" name="childGender" value="Male" checked={formData.childGender === "Male"} onChange={handleChange} required
                        className="w-4 h-4 text-[#B59E74] focus:ring-[#B59E74]" /> Male
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                      <input type="radio" name="childGender" value="Female" checked={formData.childGender === "Female"} onChange={handleChange}
                        className="w-4 h-4 text-[#B59E74] focus:ring-[#B59E74]" /> Female
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* 3. Parents' Info */}
            <div>
              <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest border-b border-[#B59E74]/30 pb-2 mb-4">
                Parents' Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="text-xs font-bold text-gray-600">Father's Full Name *</label>
                  <input type="text" name="fatherName" value={formData.fatherName} onChange={handleChange} required placeholder="First, Middle, Last Name"
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="text-xs font-bold text-gray-600">Mother's Full Maiden Name *</label>
                  <input type="text" name="motherMaidenName" value={formData.motherMaidenName} onChange={handleChange} required placeholder="First, Middle, Last Maiden Name"
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1 md:col-span-2">
                  <label className="text-xs font-bold text-gray-600">Complete Address *</label>
                  <textarea rows="2" name="address" value={formData.address} onChange={handleChange} required placeholder="Street Address, City, Zip Code"
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700 resize-none"></textarea>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Contact Numbers *</label>
                  <input type="tel" name="contactNumbers" value={formData.contactNumbers} onChange={handleChange} required placeholder="Primary phone number"
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-bold text-gray-600">Parents' Marriage Status *</label>
                  <select name="parentsMarriageStatus" value={formData.parentsMarriageStatus} onChange={handleChange} required
                    className="p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700">
                    <option value="Married in Church">Married in Church</option>
                    <option value="Civil Marriage">Civil Marriage</option>
                    <option value="Not Married">Not Married</option>
                  </select>
                </div>
              </div>
            </div>

            {/* 4. Godparents Info */}
            <div>
              <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest border-b border-[#B59E74]/30 pb-2 mb-4">
                Sponsors / Godparents
              </h3>
              <p className="text-xs text-gray-500 italic mb-4">
                Note: 1 pair of sponsors is included in the base fee. Additional sponsors are Php 50.00 per head.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <div className="flex flex-col gap-2 p-4 bg-white border border-gray-200 rounded-xl">
                  <label className="text-xs font-bold text-[#B59E74]">Primary Godfather (Ninong) *</label>
                  <input type="text" name="godfatherName" value={formData.godfatherName} onChange={handleChange} required placeholder="Full Name"
                    className="p-2 border-b border-gray-300 focus:outline-none focus:border-[#B59E74] bg-transparent text-gray-700 text-sm" />
                </div>
                <div className="flex flex-col gap-2 p-4 bg-white border border-gray-200 rounded-xl">
                  <label className="text-xs font-bold text-[#B59E74]">Primary Godmother (Ninang) *</label>
                  <input type="text" name="godmotherName" value={formData.godmotherName} onChange={handleChange} required placeholder="Full Name"
                    className="p-2 border-b border-gray-300 focus:outline-none focus:border-[#B59E74] bg-transparent text-gray-700 text-sm" />
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold text-gray-600">Additional Sponsors</label>
                {sponsorsList.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-2">
                    {sponsorsList.map((sponsor, index) => (
                      <div key={index} className="flex items-center gap-2 bg-[#F6F5ED] border border-[#B59E74]/30 text-[#B59E74] px-3 py-1.5 rounded-full text-sm font-medium">
                        <span>{sponsor}</span>
                        <button type="button" onClick={() => handleRemoveSponsor(index)}
                          className="text-[#B59E74] hover:text-red-500 font-bold focus:outline-none" title="Remove sponsor">✕</button>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <input type="text" value={sponsorInput} onChange={(e) => setSponsorInput(e.target.value)} onKeyDown={handleKeyDown}
                    placeholder="Type a name and hit Enter..."
                    className="flex-1 p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#B59E74] bg-white text-gray-700" />
                  <button type="button" onClick={handleAddSponsor} disabled={!sponsorInput.trim()}
                    className="w-12 h-12 flex items-center justify-center bg-[#B59E74] hover:bg-[#9c8760] text-white rounded-lg font-bold text-2xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    title="Add Sponsor">+</button>
                </div>
              </div>
            </div>

            <hr className="border-gray-200" />

            {/* Guidelines & Fees Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm flex flex-col h-full">
                <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest mb-4 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Requirements for Baptism
                </h3>
                <ul className="flex flex-col gap-2 text-sm text-gray-600 font-serif">
                  <li><strong>1. Birth Certificate</strong> with Registry No. (from City Hall or PSA). Present original and submit photocopy.</li>
                  <li><strong>2. Marriage Certificate of Parents</strong> (If married). Present original and submit photocopy.</li>
                  <li><strong>3. Permit for Baptism</strong> (for non-parishioners) from a parish near your residence.</li>
                  <li><strong>4. Certificate of No Records</strong> (for 2 yrs old & above) from 3 neighboring parishes.</li>
                </ul>
                <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm font-bold text-center border border-red-100">
                  "NO SEMINAR, NO BAPTISM" <br />
                  <span className="text-xs font-normal">Be on time: 30 minutes before schedule.</span>
                </div>
                <div className="mt-6 flex-grow flex flex-col justify-end">
                  <div className="bg-[#B59E74]/10 rounded-xl border-2 border-dashed border-[#B59E74]/50 p-6 flex flex-col items-center justify-center text-center h-full">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 text-[#B59E74] mb-3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0l3 3m-3-3l-3 3M6.75 19.5a4.5 4.5 0 01-1.41-8.775 5.25 5.25 0 0110.233-2.33 3 3 0 013.758 3.848A3.752 3.752 0 0118 19.5H6.75z" />
                    </svg>
                    <h4 className="text-sm font-bold text-gray-800 uppercase tracking-widest mb-1">Submit Your Documents</h4>
                    <p className="text-xs text-gray-500 mb-4 max-w-xs">Please compile your scanned requirements and upload them to our secure Parish Google Drive folder.</p>
                    <a href="https://drive.google.com/drive/folders/1K3j5gWyYykh6lTRJB0LjchlcT7As8Jox?usp=sharing" target="_blank" rel="noopener noreferrer"
                      className="bg-[#B59E74] hover:bg-[#9c8760] text-white px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors shadow-sm flex items-center gap-2">
                      <span>📁</span> Open Upload Folder
                    </a>
                  </div>
                </div>
              </div>

              <div className="bg-[#B59E74]/10 p-6 rounded-xl border border-[#B59E74]/30 shadow-sm flex flex-col gap-4 h-full">
                <div>
                  <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest mb-2">Schedule & Fees</h3>
                  <ul className="text-sm text-gray-700 font-serif space-y-2">
                    <li><strong>A. Solo/Individual:</strong> Php 2,500.00 (Tue-Sat: 9:30am, 10:00am, 10:30am, 11:00am). Includes 1 pair of sponsors & certificate.</li>
                    <li><strong>B. Sunday Baptism</strong></li>
                    <li className="text-xs italic text-gray-500 mt-1">Add-ons: Extra sponsor Php 50.00/head | Baptismal Candle Php 80.00/set</li>
                  </ul>
                </div>
                <div className="border-t border-[#B59E74]/20 pt-4 mt-auto">
                  <h3 className="text-sm font-bold text-[#B59E74] uppercase tracking-widest mb-2">Dress Code</h3>
                  <ul className="text-sm text-gray-700 font-serif space-y-1">
                    <li><strong>Child:</strong> Baptismal gown/White dress (girls) / White polo (boys) / White cloth.</li>
                    <li><strong>Adults:</strong> Sunday Best. NO shorts, sandos, sleeveless, spaghetti blouses, leggings, or slippers.</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Declaration & Signature */}
            <DeclarationBlock
              declaration="I declare that the information provided above is true and correct, and I respectfully request the Sacrament of Baptism for the child named above. I also acknowledge the fees and dress code required."
              consent={formData.declaration_consent}
              signature={formData.submitter_signature}
              onChange={handleChange}
            />

            <div className="pt-2 pb-4">
              <button type="submit" disabled={loading}
                className="w-full bg-[#B59E74] hover:bg-[#9c8760] text-white font-bold text-lg py-4 rounded-xl transition-all shadow-md disabled:opacity-70 disabled:cursor-not-allowed">
                {loading ? "Submitting..." : "Submit Registration"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default BaptismFormModal;